1. open install.py
2. add your proxies to proxies.txt
3. run main.py and choose your proxy type
4. start checking zzz
5. optional set a webhook in the config
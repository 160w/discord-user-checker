import subprocess
import sys
import os

def install_requirements():
    print("Installing required packages...")
    print("="*50)
    
    requirements = [
        "requests",
        "colorama"
    ]
    
    for package in requirements:
        try:
            print(f"\nInstalling {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
            print(f"✓ {package} installed")
        except Exception as e:
            print(f"✗ Failed to install {package}: {e}")
    
    print("\n" + "="*50)
    print("All packages installed!")
    print("\nYou can now run the main script.")
    input("\nPress ENTER to exit...")

if __name__ == "__main__":
    install_requirements()
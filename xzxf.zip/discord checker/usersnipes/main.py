import requests
import json
import itertools
import string
import time
import sys
import random
import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    RESET = '\033[0m'

class DiscordUsernameChecker:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Content-Type': 'application/json',
        })
        self.available_usernames = []
        self.proxies = []
        self.current_proxy_index = 0
        self.checked_count = 0
        self.successful_checks = 0
        self.failed_checks = 0
        self.proxy_cooldown = {}
        self.config = {}
        self.proxy_type = "rotating"
        self.word_list = []
        
        self.create_default_files()
        self.load_config()
        self.set_proxy_type()
        self.load_proxies()
        self.load_word_list()
        
        if not self.proxies:
            print("\n" + "!"*60)
            print("ERROR: No proxies loaded!")
            print("!"*60)
            print("\nPlease add your proxies to proxies.txt")
            print("Each proxy on a new line")
            print("\nClosing in 3 seconds...")
            time.sleep(3)
            sys.exit(1)
    
    def create_default_files(self):
        print("\n[1/3] Checking for required files...")
        
        if not os.path.exists("proxies.txt"):
            open("proxies.txt", "w").close()
            print("  - Created proxies.txt")
        
        if not os.path.exists("list.txt"):
            open("list.txt", "w").close()
            print("  - Created list.txt")
        
        if not os.path.exists("available.txt"):
            open("available.txt", "w").close()
            print("  - Created available.txt")
        
        if not os.path.exists("config.json"):
            default_config = {
                "webhook_url": "",
                "auto_save": True,
                "max_workers": 50,
                "delay_between_checks": 0,
                "proxy_type": ""
            }
            with open("config.json", "w") as f:
                json.dump(default_config, f, indent=4)
            print("  - Created config.json")
        
        if not os.path.exists("words.txt"):
            print("\n[2/3] Downloading English word list...")
            try:
                url = "https://raw.githubusercontent.com/dwyl/english-words/master/words.txt"
                response = requests.get(url, timeout=30)
                if response.status_code == 200:
                    with open("words.txt", "w", encoding='utf-8') as f:
                        f.write(response.text)
                    print("  - Downloaded 370,000+ English words")
                else:
                    print("  - Download failed, creating sample word list...")
                    with open("words.txt", "w") as f:
                        sample_words = ["apple", "banana", "cherry", "dog", "cat", "house", "car", "phone", "computer", "laptop"]
                        for word in sample_words:
                            f.write(f"{word}\n")
                    print("  - Created sample word list with 10 words")
            except:
                print("  - Download failed, creating sample word list...")
                with open("words.txt", "w") as f:
                    sample_words = ["apple", "banana", "cherry", "dog", "cat", "house", "car", "phone", "computer", "laptop"]
                    for word in sample_words:
                        f.write(f"{word}\n")
                print("  - Created sample word list with 10 words")
        
        print("\n[3/3] Files ready!")
    
    def is_valid_discord_username(self, username):
        if len(username) < 2 or len(username) > 32:
            return False
        if not re.match(r'^[a-zA-Z0-9_.]+$', username):
            return False
        if username[0] in '_.' or username[-1] in '_.':
            return False
        if '__' in username or '..' in username:
            return False
        return True
    
    def load_word_list(self):
        try:
            with open("words.txt", "r", encoding='utf-8') as f:
                all_words = [line.strip().lower() for line in f if line.strip() and not line.strip().startswith('#')]
            
            self.word_list = []
            for word in all_words:
                if word.isalpha() and 5 <= len(word) <= 12:
                    self.word_list.append(word)
            
            print(f"\nLoaded {len(self.word_list)} English words (5-12 letters)")
                
        except Exception as e:
            print(f"Error loading words: {e}")
            self.word_list = []
    
    def load_config(self):
        try:
            with open("config.json", "r") as f:
                self.config = json.load(f)
            if self.config.get("webhook_url"):
                print(f"Webhook configured")
            
            self.max_workers = self.config.get("max_workers", 50)
            self.delay = self.config.get("delay_between_checks", 0)
            
            if self.config.get("proxy_type"):
                self.proxy_type = self.config.get("proxy_type")
                
        except Exception as e:
            print(f"Error loading config: {e}")
            self.config = {}
            self.max_workers = 50
            self.delay = 0
    
    def set_proxy_type(self):
        if self.config.get("proxy_type"):
            print(f"Proxy mode: {self.proxy_type.upper()}")
            return
        
        print("\n" + "="*50)
        print("Select proxy type:")
        print("1. Rotating residential proxy (auto-rotates IPs)")
        print("2. Normal static proxy (fixed IP)")
        print("="*50)
        
        while True:
            choice = input("\nChoice (1 or 2): ").strip()
            if choice == "1":
                self.proxy_type = "rotating"
                break
            elif choice == "2":
                self.proxy_type = "normal"
                break
            else:
                print("Invalid choice. Please enter 1 or 2.")
        
        self.config["proxy_type"] = self.proxy_type
        with open("config.json", "w") as f:
            json.dump(self.config, f, indent=4)
        
        print(f"Proxy mode set to: {self.proxy_type.upper()}")
    
    def parse_proxy(self, line):
        line = line.strip()
        
        if '@' in line:
            try:
                auth_part, host_part = line.split('@')
                if ':' in auth_part:
                    username, password = auth_part.split(':', 1)
                    proxy_url = f'http://{username}:{password}@{host_part}'
                    return {
                        'http': proxy_url,
                        'https': proxy_url,
                        'original': line
                    }
            except:
                pass
        
        if ':' in line and len(line.split(':')) == 2:
            try:
                proxy_url = f'http://{line}'
                return {
                    'http': proxy_url,
                    'https': proxy_url,
                    'original': line
                }
            except:
                pass
        
        return None
    
    def load_proxies(self):
        try:
            with open("proxies.txt", "r") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        proxy = self.parse_proxy(line)
                        if proxy:
                            self.proxies.append(proxy)
            
            if self.proxies:
                print(f"\nLoaded {len(self.proxies)} proxies")
                print(f"First proxy: {self.proxies[0]['original']}")
            else:
                print(f"\nNo proxies found in proxies.txt")
                print("Make sure you've added your proxies to proxies.txt")
                print("Each proxy on a new line")
                
        except Exception as e:
            print(f"Error loading proxies: {e}")
            self.proxies = []
    
    def send_webhook(self, username):
        webhook_url = self.config.get("webhook_url")
        if not webhook_url:
            return
        
        try:
            payload = {
                "content": f"`{username}` is available"
            }
            requests.post(webhook_url, json=payload, timeout=5)
        except:
            pass
    
    def get_next_proxy(self):
        if not self.proxies:
            return None
        
        if self.proxy_type == "normal":
            for _ in range(len(self.proxies)):
                proxy = self.proxies[self.current_proxy_index]
                self.current_proxy_index = (self.current_proxy_index + 1) % len(self.proxies)
                
                proxy_key = proxy['original']
                if proxy_key in self.proxy_cooldown:
                    if time.time() < self.proxy_cooldown[proxy_key]:
                        continue
                    else:
                        del self.proxy_cooldown[proxy_key]
                
                return proxy
            
            if self.proxy_cooldown:
                min_cooldown = min(self.proxy_cooldown.values())
                wait_time = min_cooldown - time.time()
                if wait_time > 0:
                    time.sleep(wait_time)
            
            return self.proxies[0]
        
        else:
            proxy = self.proxies[self.current_proxy_index]
            self.current_proxy_index = (self.current_proxy_index + 1) % len(self.proxies)
            return proxy
    
    def check_username(self, username):
        proxy = self.get_next_proxy()
        if not proxy:
            return False
        
        try:
            url = "https://discord.com/api/v9/unique-username/username-attempt-unauthed"
            payload = {"username": username}
            
            response = self.session.post(url, json=payload, proxies=proxy, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                self.successful_checks += 1
                
                if not data.get("taken", True):
                    return True
                return False
                
            elif response.status_code == 429:
                retry_data = response.json()
                retry_after = retry_data.get('retry_after', 30)
                
                if self.proxy_type == "rotating":
                    time.sleep(0.5)
                    return False
                else:
                    self.proxy_cooldown[proxy['original']] = time.time() + retry_after
                    return False
                
            elif response.status_code == 403:
                if proxy in self.proxies:
                    self.proxies.remove(proxy)
                return False
                
            else:
                self.failed_checks += 1
                return False
                
        except:
            return False
    
    def generate_3c(self):
        chars = string.ascii_lowercase + string.digits
        usernames = [''.join(combo) for combo in itertools.product(chars, repeat=3)]
        valid = [u for u in usernames if self.is_valid_discord_username(u)]
        random.shuffle(valid)
        return valid
    
    def generate_3l(self):
        usernames = [''.join(combo) for combo in itertools.product(string.ascii_lowercase, repeat=3)]
        random.shuffle(usernames)
        return usernames
    
    def generate_4c(self):
        chars = string.ascii_lowercase + string.digits
        usernames = [''.join(combo) for combo in itertools.product(chars, repeat=4)]
        valid = [u for u in usernames if self.is_valid_discord_username(u)]
        random.shuffle(valid)
        return valid
    
    def generate_4l(self):
        usernames = [''.join(combo) for combo in itertools.product(string.ascii_lowercase, repeat=4)]
        random.shuffle(usernames)
        return usernames
    
    def get_all_english_words(self):
        shuffled = self.word_list.copy()
        random.shuffle(shuffled)
        return shuffled
    
    def save_available_usernames(self):
        if not self.available_usernames:
            return
        
        with open("available.txt", "w") as f:
            for username in self.available_usernames:
                f.write(f"{username}\n")
        
        print(f"\nSaved {len(self.available_usernames)} usernames to available.txt")
    
    def load_usernames_from_file(self, filename="list.txt"):
        if not os.path.exists(filename):
            return None
            
        try:
            with open(filename, 'r') as f:
                usernames = []
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        if self.is_valid_discord_username(line):
                            usernames.append(line)
                random.shuffle(usernames)
                return usernames
        except:
            return None
    
    def check_usernames_from_list(self, usernames):
        if not usernames:
            print("No usernames to check!")
            return
        
        usernames = list(dict.fromkeys(usernames))
        random.shuffle(usernames)
        
        self.checked_count = 0
        self.successful_checks = 0
        self.failed_checks = 0
        total = len(usernames)
        
        print(f"\nChecking {total:,} usernames...")
        start_time = time.time()
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_username = {executor.submit(self.check_username, username): username for username in usernames}
            
            for future in as_completed(future_to_username):
                username = future_to_username[future]
                self.checked_count += 1
                
                try:
                    if future.result():
                        print(f"{Colors.GREEN}[available]{Colors.RESET} {username}")
                        sys.stdout.flush()
                        self.available_usernames.append(username)
                        
                        with open("available.txt", "a") as f:
                            f.write(f"{username}\n")
                        
                        if self.config.get("webhook_url"):
                            self.send_webhook(username)
                    else:
                        print(f"{Colors.RED}[taken]{Colors.RESET} {username}")
                        sys.stdout.flush()
                        
                except:
                    pass
                
                if self.delay > 0:
                    time.sleep(self.delay)
        
        elapsed = time.time() - start_time
        print(f"\nResults")
        print(f"Total checked: {self.checked_count:,}")
        print(f"Available: {len(self.available_usernames):,}")
        print(f"Time: {elapsed:.2f} seconds")
        print(f"Speed: {self.checked_count/elapsed:.1f} checks/second")
        
        if self.available_usernames:
            self.save_available_usernames()
    
    def test_proxies(self):
        print("\n" + "="*50)
        print("TESTING PROXIES")
        print("="*50)
        
        if not self.proxies:
            print("No proxies to test!")
            print("\nPlease add proxies to proxies.txt first")
            return
        
        print(f"\nTesting {len(self.proxies)} proxies...")
        working = 0
        test_username = f"testuser{random.randint(10000, 99999)}"
        
        for i, proxy in enumerate(self.proxies):
            try:
                print(f"Testing proxy {i+1}: {proxy['original']}")
                url = "https://discord.com/api/v9/unique-username/username-attempt-unauthed"
                payload = {"username": test_username}
                
                response = requests.post(url, json=payload, proxies=proxy, timeout=10)
                
                if response.status_code == 200:
                    print(f"  OK - Works with Discord")
                    working += 1
                elif response.status_code == 429:
                    print(f"  Rate limited (will auto-recover)")
                    working += 1
                elif response.status_code == 403:
                    print(f"  Banned by Discord")
                else:
                    print(f"  Failed (Status: {response.status_code}")
                    
            except:
                print(f"  Failed")
        
        print(f"\n" + "="*50)
        print(f"Results: {working}/{len(self.proxies)} proxies working")
        print("="*50)
    
    def run_interactive(self):
        while True:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("\n" + "="*50)
            print("       .gg/usersnipes")
            print("="*50)
            print(f"Proxies: {len(self.proxies)}")
            print(f"Mode: {self.proxy_type.upper()}")
            print(f"Workers: {self.max_workers}")
            print(f"Delay: {self.delay}s")
            print(f"English words: {len(self.word_list):,} (5-12 letters)")
            print("="*50)
            
            print("\nMain Menu")
            print("1. Check 3-character (3C)")
            print("2. Check 3-letter (3L)")
            print("3. Check 4-character (4C)")
            print("4. Check 4-letter (4L)")
            print("5. Check English words (5-12 letters)")
            print("6. Check list.txt")
            print("7. Test proxies")
            print("8. Exit")
            
            choice = input("\nChoice (1-8): ").strip()
            
            if choice == "1":
                usernames = self.generate_3c()
                self.check_usernames_from_list(usernames)
                input("\nPress ENTER to continue...")
                
            elif choice == "2":
                usernames = self.generate_3l()
                self.check_usernames_from_list(usernames)
                input("\nPress ENTER to continue...")
                
            elif choice == "3":
                usernames = self.generate_4c()
                self.check_usernames_from_list(usernames)
                input("\nPress ENTER to continue...")
                
            elif choice == "4":
                usernames = self.generate_4l()
                self.check_usernames_from_list(usernames)
                input("\nPress ENTER to continue...")
                
            elif choice == "5":
                if not self.word_list:
                    print("No English words loaded!")
                    input("\nPress ENTER to continue...")
                    continue
                usernames = self.get_all_english_words()
                self.check_usernames_from_list(usernames)
                input("\nPress ENTER to continue...")
                    
            elif choice == "6":
                usernames = self.load_usernames_from_file("list.txt")
                if usernames:
                    self.check_usernames_from_list(usernames)
                else:
                    print("No usernames found in list.txt")
                input("\nPress ENTER to continue...")
                    
            elif choice == "7":
                self.test_proxies()
                input("\nPress ENTER to continue...")
                    
            elif choice == "8":
                break

def main():
    try:
        checker = DiscordUsernameChecker()
        checker.run_interactive()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")

if __name__ == "__main__":
    main()